const s="/assets/empty_favorite.44731802.9dd26110.png";export{s as _};
